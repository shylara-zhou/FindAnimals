Page({
  data: {
    parks: [],
    selectedParkId: null,
    selectedParkName: '',
    form: {
      name: '',
      species: '',
      scientific_name: '',
      description: ''
    },
    photoPath: '',
    submitting: false
  },
  onLoad() {
    this.fetchParks()
  },
  fetchParks() {
    wx.request({
      url: 'https://wulara.top/api/parks/',
      method: 'GET',
      success: res => {
        if (res.data && res.data.code === 200) {
          this.setData({ parks: res.data.data || [] })
        }
      }
    })
  },
  onParkChange(e) {
    const index = Number(e.detail.value)
    const park = this.data.parks[index]
    if (park) {
      this.setData({ selectedParkId: park.id, selectedParkName: park.name })
    }
  },
  onInput(e) {
    const key = e.currentTarget.dataset.key
    const value = e.detail.value
    this.setData({ [`form.${key}`]: value })
  },
  choosePhoto() {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        const path = (res.tempFilePaths || [])[0]
        if (path) this.setData({ photoPath: path })
      }
    })
  },
  submit() {
    if (this.data.submitting) return
    const token = wx.getStorageSync('token')
    const userId = wx.getStorageSync('user_id')
    if (!token || !userId) {
      wx.showToast({ title: '请先登录', icon: 'none' })
      return
    }

    // Client-side rate limit: 1 minute
    const lastSubmitTime = wx.getStorageSync('last_submit_time_upload') || 0
    const now = Date.now()
    if (now - lastSubmitTime < 60000) {
      const remaining = Math.ceil((60000 - (now - lastSubmitTime)) / 1000)
      wx.showToast({ title: `请稍等 ${remaining} 秒再试`, icon: 'none' })
      return
    }

    const { name, species, scientific_name, description } = this.data.form
    const { selectedParkId } = this.data
    if (!name || !species || !selectedParkId) {
      wx.showToast({ title: '请填写名称、品种并选择公园', icon: 'none' })
      return
    }
    this.setData({ submitting: true })
    const hasPhoto = !!this.data.photoPath
    if (hasPhoto) {
      wx.uploadFile({
        url: 'https://wulara.top/api/animals/',
        filePath: this.data.photoPath,
        name: 'photo',
        header: { 'Authorization': 'Token ' + token },
        formData: {
          name,
          species,
          scientific_name,
          description,
          park: selectedParkId,
          discoverer_id: userId,
          discovered_at: new Date().toISOString()
        },
        success: res => {
          let data = {}
          try { data = JSON.parse(res.data) } catch (e) {}
          if (data && data.code === 200 && data.data && data.data.id) {
            wx.setStorageSync('last_submit_time_upload', Date.now())
            wx.showToast({
              title: '谢谢您的关心，丰富了福州动物图鉴！您真棒！您的信息已提交等待wulara审核，如果很急赶紧联系他，嘿嘿',
              icon: 'none',
              duration: 3000
            })
            const id = data.data.id
            setTimeout(() => { wx.navigateTo({ url: '/pages/animal/detail?id=' + id }) }, 3000)
          } else {
            wx.showToast({ title: (data && data.msg) || '上传失败', icon: 'none' })
          }
        },
        fail: () => wx.showToast({ title: '网络错误', icon: 'none' }),
        complete: () => this.setData({ submitting: false })
      })
    } else {
      wx.request({
        url: 'https://wulara.top/api/animals/',
        method: 'POST',
        header: {
          'content-type': 'application/json',
          'Authorization': 'Token ' + token
        },
        data: {
          name,
          species,
          scientific_name,
          description,
          park: selectedParkId,
          discoverer_id: userId,
          discovered_at: new Date().toISOString()
        },
        success: res => {
          if (res.data && res.data.code === 200 && res.data.data && res.data.data.id) {
            wx.setStorageSync('last_submit_time_upload', Date.now())
            wx.showToast({
              title: '谢谢您的关心，丰富了福州动物图鉴！您真棒！您的信息已提交等待wulara审核，如果很急赶紧联系他，嘿嘿',
              icon: 'none',
              duration: 3000
            })
            const id = res.data.data.id
            setTimeout(() => { wx.navigateTo({ url: '/pages/animal/detail?id=' + id }) }, 3000)
          } else {
            wx.showToast({ title: res.data.msg || '上传失败', icon: 'none' })
          }
        },
        fail: () => wx.showToast({ title: '网络错误', icon: 'none' }),
        complete: () => this.setData({ submitting: false })
      })
    }
  }
})