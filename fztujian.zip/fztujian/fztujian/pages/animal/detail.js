Page({
  data: {
    id: null,
    animal: {},
    comments: [],
    commentText: '',
    commentPage: 1,
    commentTotalPages: 1,
    commentTotal: 0,
    loadingComments: false,
    refreshing: false
  },
  onLoad: function(options) {
    const { id } = options || {};
    if (!id) {
      wx.showToast({ title: '缺少ID', icon: 'none' });
      return;
    }
    this.setData({ id, commentPage: 1 });
    this.fetchDetail();
    this.fetchComments();
  },
  fetchDetail: function() {
    const id = this.data.id;
    wx.request({
      url: 'https://wulara.top/api/animals/' + id + '/',
      method: 'GET',
      success: res => {
        if (res.data.code === 200) {
          this.setData({ animal: res.data.data })
        }
      }
    })
  },
  fetchComments: function(pageArg) {
    const id = this.data.id;
    const token = wx.getStorageSync('token')
    const headers = token ? { 'Authorization': 'Token ' + token } : {}
    const page = Number(pageArg || this.data.commentPage || 1)
    this.setData({ loadingComments: true })
    wx.request({
      url: 'https://wulara.top/api/comments/?animal=' + id + '&page=' + page,
      method: 'GET',
      header: headers,
      success: res => {
        if (res.statusCode === 401) {
          wx.showToast({ title: '请先登录后查看评论', icon: 'none' })
          this.setData({ loadingComments: false })
          return
        }
        if (res.data && res.data.code === 200) {
          const list = (res.data.data || []).map(item => ({
            ...item,
            created_at_display: this.formatTime(item.created_at)
          }))
          const pagination = res.data.pagination || {}
          const nextData = page === 1 ? list : (this.data.comments || []).concat(list)
          this.setData({
            comments: nextData,
            commentPage: pagination.page || page || 1,
            commentTotalPages: pagination.total_pages || 1,
            commentTotal: pagination.total || nextData.length,
            loadingComments: false
          })
        }
      },
      fail: () => {
        this.setData({ loadingComments: false })
        wx.showToast({ title: '评论加载失败', icon: 'none' })
      },
      complete: () => {
        if (this.data.refreshing) {
          wx.stopPullDownRefresh()
          this.setData({ refreshing: false })
        }
      }
    })
  },
  formatTime: function(isoStr) {
    if (!isoStr) return ''
    const d = new Date(isoStr)
    const Y = d.getFullYear()
    const M = String(d.getMonth() + 1).padStart(2, '0')
    const D = String(d.getDate()).padStart(2, '0')
    const h = String(d.getHours()).padStart(2, '0')
    const m = String(d.getMinutes()).padStart(2, '0')
    return `${Y}-${M}-${D} ${h}:${m}`
  },
  onCommentInput: function(e) {
    this.setData({ commentText: e.detail.value })
  },
  sendComment: function() {
    const token = wx.getStorageSync('token')
    const userId = wx.getStorageSync('user_id')
    if (!token || !userId) {
      wx.showToast({ title: '请先登录', icon: 'none' })
      return
    }

    // Client-side rate limit: 1 minute
    const lastSubmitTime = wx.getStorageSync('last_submit_time_comment') || 0
    const now = Date.now()
    if (now - lastSubmitTime < 60000) {
      const remaining = Math.ceil((60000 - (now - lastSubmitTime)) / 1000)
      wx.showToast({ title: `请稍等 ${remaining} 秒再试`, icon: 'none' })
      return
    }

    const content = (this.data.commentText || '').trim()
    if (!content) {
      wx.showToast({ title: '请输入评论内容', icon: 'none' })
      return
    }
    wx.request({
      url: 'https://wulara.top/api/comments/',
      method: 'POST',
      header: {
        'content-type': 'application/json',
        'Authorization': 'Token ' + token
      },
      data: {
        animal: Number(this.data.id),
        user_id: userId,
        content
      },
      success: res => {
        if (res.data && res.data.code === 200) {
          wx.setStorageSync('last_submit_time_comment', Date.now())
          wx.showToast({ title: '已发布', icon: 'success' })
          this.setData({ commentText: '', commentPage: 1, comments: [] })
          this.fetchComments(1)
        } else {
          wx.showToast({ title: res.data.msg || '发布失败', icon: 'none' })
        }
      },
      fail: () => wx.showToast({ title: '网络错误', icon: 'none' })
    })
  },
  loadMoreComments: function() {
    if (this.data.loadingComments) return
    const { commentPage, commentTotalPages, commentTotal } = this.data
    if (!commentTotal || Number(commentTotal) === 0) {
      wx.showToast({ title: '暂无评论', icon: 'none' })
      return
    }
    if (Number(commentPage) >= Number(commentTotalPages)) {
      wx.showToast({ title: '已到底', icon: 'none' })
      return
    }
    const nextPage = Number(commentPage) + 1
    this.setData({ commentPage: nextPage })
    this.fetchComments(nextPage)
  },
  onReachBottom: function() {
    this.loadMoreComments()
  },
  onPullDownRefresh: function() {
    this.setData({
      refreshing: true,
      commentPage: 1,
      comments: [],
      commentTotalPages: 1,
      commentTotal: 0
    })
    this.fetchComments(1)
  }
})