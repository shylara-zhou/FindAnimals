Page({
  data: {
    parks: [],
    loading: true,
    searchKeyword: '',
    searchResults: []
  },
  onLoad: function (options) {
    // 检查登录状态
    this.checkLoginStatus();
    this.fetchParks();
  },
  
  checkLoginStatus() {
    const token = wx.getStorageSync('token');
    if (!token) {
      wx.redirectTo({
        url: '/pages/index/index'
      });
    }
  },

  fetchParks: function() {
    wx.request({
      url: 'https://wulara.top/api/parks/',
      method: 'GET',
      success: res => {
        if (res.data.code === 200) {
          this.setData({ parks: (res.data.data || []), loading: false });
        }
      }
    });
  },
  viewAnimals: function(e) {
      const parkId = e.currentTarget.dataset.id;
      const parkName = e.currentTarget.dataset.name;
      
      // 处理未探索区域的点击
      if (parkId === 'unexplored') {
        wx.showToast({
          title: '这里是未探索区域，等待你的发现！',
          icon: 'none',
          duration: 2000
        });
        return;
      }
      
      // 正常导航到动物列表页面
      wx.navigateTo({
          url: '/pages/home/animals/animals?park_id=' + parkId + '&park_name=' + parkName
      })
  },
  onSearchInput: function(e) {
    this.setData({ searchKeyword: e.detail.value })
  },
  doGlobalSearch: function() {
    const keyword = this.data.searchKeyword && this.data.searchKeyword.trim();
    if (!keyword) {
      wx.showToast({ title: '请输入关键词', icon: 'none' })
      return;
    }
    wx.request({
      url: 'https://wulara.top/api/animals/search/?keyword=' + encodeURIComponent(keyword),
      method: 'GET',
      success: res => {
        if (res.data.code === 200) {
          this.setData({ searchResults: res.data.data })
        }
      }
    })
  },
  viewDetail: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/pages/animal/detail?id=' + id })
  }
})