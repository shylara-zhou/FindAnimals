Page({
  data: {
    userInfo: {}
  },
  onLoad() {
    // 检查登录状态
    this.checkLoginStatus();
    const stored = wx.getStorageSync('userInfo') || {}
    this.setData({ userInfo: stored })
  },
  
  checkLoginStatus() {
    const token = wx.getStorageSync('token');
    if (!token) {
      wx.redirectTo({
        url: '/pages/index/index'
      });
    }
  },

  goUpload() {
    wx.navigateTo({ url: '/pages/animal/upload/upload' })
  },
  goMyUploads() {
    wx.navigateTo({ url: '/pages/mine/my_uploads/my_uploads' })
  },
  goAbout() {
    wx.navigateTo({ url: '/pages/mine/about/about' })
  }
})