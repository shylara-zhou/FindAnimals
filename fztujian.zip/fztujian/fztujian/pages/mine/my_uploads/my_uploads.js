Page({
  data: {
    list: []
  },
  onShow() {
    this.fetchMyUploads()
  },
  formatStatus(status) {
    const map = { pending: '待审核', approved: '已通过', rejected: '已拒绝' }
    return map[status] || status
  },
  fetchMyUploads() {
    const token = wx.getStorageSync('token')
    if (!token) {
      wx.showToast({ title: '请先登录', icon: 'none' })
      return
    }
    wx.request({
      url: 'https://wulara.top/api/my/animals/',
      method: 'GET',
      header: { 'Authorization': 'Token ' + token },
      success: res => {
        if (res.data && res.data.code === 200) {
          this.setData({ list: res.data.data || [] })
        }
      }
    })
  },
  viewDetail(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: '/pages/animal/detail?id=' + id })
  }
})