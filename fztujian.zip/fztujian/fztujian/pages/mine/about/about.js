Page({
  data: {},
  onLoad() {}
})