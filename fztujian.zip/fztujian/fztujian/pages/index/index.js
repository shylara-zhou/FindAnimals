// index.js

Page({
  data: {
    motto: 'Hello World',
    userInfo: { nickName: '' },
    hasUserInfo: false,
    loginType: 'quick', // quick, password, register
    username: '',
    password: '',
    confirmPassword: '',
    phone: ''
  },
  bindViewTap() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  switchLoginType(e) {
    this.setData({
      loginType: e.currentTarget.dataset.type
    })
  },
  give: function(e){		//快速登录
    if (!this.data.userInfo.nickName) {
        wx.showToast({
            title: '请先输入昵称',
            icon: 'none'
        })
        return
    }
    console.log("执行give服务器这里了！！"),
    wx.request({
      url: 'https://wulara.top/wx_login/',	//获取服务器地址，此处为云服务器地址
      method: "GET",
      header:{
        "content-type": "application/x-www-form-urlencoded"		//使用POST方法要带上这个header
      },
      data: {		//向服务器发送的信息
        mname: this.data.userInfo.nickName, // Use the nickname from userInfo
        avatar_url: this.data.userInfo.avatarUrl,
      },
      success: res => {
        console.log(res)
        if (res.statusCode == 200 && res.data.code === 200) {
          console.log("Login success", res.data)
          if (res.data.data && res.data.data.token) {
              wx.setStorageSync('token', res.data.data.token)
              if (res.data.data.user_id) {
                wx.setStorageSync('user_id', res.data.data.user_id)
              }
              wx.showToast({
                  title: '登录成功',
                  icon: 'success',
                  duration: 1500,
                  success: () => {
                    setTimeout(() => {
                        wx.switchTab({
                            url: '../home/home'
                        })
                    }, 1500)
                  }
              })
          }
          this.setData({
            result: res.data	//服务器返回的结果 
          })
        } else {
            wx.showToast({
                title: '登录失败: ' + (res.data.msg || '未知错误'),
                icon: 'none'
            })
        }
      },
      fail: err => {
          console.error("Request failed", err)
          wx.showToast({
              title: '网络请求失败',
              icon: 'none'
          })
      }
    })
  },
  passwordLogin: function(e){		//密码登录
    if (!this.data.username || !this.data.password) {
        wx.showToast({
            title: '请输入用户名和密码',
            icon: 'none'
        })
        return
    }
    wx.request({
      url: 'https://wulara.top/api/login/',
      method: "POST",
      header:{
        "content-type": "application/json"
      },
      data: {
        username: this.data.username,
        password: this.data.password
      },
      success: res => {
        console.log(res)
        if (res.statusCode == 200 && res.data.code === 200) {
          console.log("Login success", res.data)
          if (res.data.data && res.data.data.token) {
              wx.setStorageSync('token', res.data.data.token)
              if (res.data.data.user_id) {
                wx.setStorageSync('user_id', res.data.data.user_id)
              }
              wx.showToast({
                  title: '登录成功',
                  icon: 'success',
                  duration: 1500,
                  success: () => {
                    setTimeout(() => {
                        wx.switchTab({
                            url: '../home/home'
                        })
                    }, 1500)
                  }
              })
          }
        } else {
            wx.showToast({
                title: '登录失败: ' + (res.data.msg || '未知错误'),
                icon: 'none'
            })
        }
      },
      fail: err => {
          console.error("Request failed", err)
          wx.showToast({
              title: '网络请求失败',
              icon: 'none'
          })
      }
    })
  },
  register: function(e){		//注册
    if (!this.data.username || !this.data.password) {
        wx.showToast({
            title: '请输入用户名和密码',
            icon: 'none'
        })
        return
    }
    if (this.data.password !== this.data.confirmPassword) {
        wx.showToast({
            title: '两次密码输入不一致',
            icon: 'none'
        })
        return
    }
    wx.request({
      url: 'https://wulara.top/api/register/',
      method: "POST",
      header:{
        "content-type": "application/json"
      },
      data: {
        username: this.data.username,
        password: this.data.password,
        nickname: this.data.username,
        phone: this.data.phone
      },
      success: res => {
        console.log(res)
        if (res.statusCode == 200 && res.data.code === 200) {
          console.log("Register success", res.data)
          if (res.data.data && res.data.data.token) {
              wx.setStorageSync('token', res.data.data.token)
              if (res.data.data.user_id) {
                wx.setStorageSync('user_id', res.data.data.user_id)
              }
              wx.showToast({
                  title: '注册成功',
                  icon: 'success',
                  duration: 1500,
                  success: () => {
                    setTimeout(() => {
                        wx.switchTab({
                            url: '../home/home'
                        })
                    }, 1500)
                  }
              })
          }
        } else {
            wx.showToast({
                title: '注册失败: ' + (res.data.msg || '未知错误'),
                icon: 'none'
            })
        }
      },
      fail: err => {
          console.error("Request failed", err)
          wx.showToast({
              title: '网络请求失败',
              icon: 'none'
          })
      }
    })
  },
  getTitle: function(e){		//与服务器进行交互
    wx.request({
      url: 'http://127.0.0.1:8000/',
      method:'GET',
      success: (res)=>{
        console.log(res.data)
        this.setData({
          motto:res.data//这个点击显示LOVE!的功能一定要保留，这是记录开始也是充满爱的关键！
        })
      }
    })
  },
  onInputChange(e) {
    const nickName = e.detail.value
    this.setData({
      "userInfo.nickName": nickName,
      hasUserInfo: !!nickName,
    })
  },
  onUsernameChange(e) {
    this.setData({
      username: e.detail.value
    })
  },
  onPasswordChange(e) {
    this.setData({
      password: e.detail.value
    })
  },
  onConfirmPasswordChange(e) {
    this.setData({
      confirmPassword: e.detail.value
    })
  },
  onPhoneChange(e) {
    this.setData({
      phone: e.detail.value
    })
  },
})
