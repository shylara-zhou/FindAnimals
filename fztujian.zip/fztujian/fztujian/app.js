// app.js
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 检查登录状态
    this.checkLoginStatus();

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },
  
  checkLoginStatus() {
    // 检查是否有登录令牌
    const token = wx.getStorageSync('token');
    
    // 如果没有令牌，跳转到登录页面
    if (!token) {
      wx.redirectTo({
        url: '/pages/index/index'
      });
    }
  },
  
  globalData: {
    userInfo: null
  }
})
